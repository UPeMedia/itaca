var App =  angular.module('App',["ngSanitize"]);

App.controller('appCtrl', function($scope){


  $scope.snipped = {
    menu:"snipped/menu.html"
  };

});
